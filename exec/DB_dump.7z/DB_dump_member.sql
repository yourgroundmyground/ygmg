SELECT * FROM member;

INSERT INTO member(id, kakao_email, member_birth, member_name, member_nickname, member_weight, profile_url, role) VALUES(1, "dksudgo1015@daum.net", "0107", "보영", "o0o", 44, "https://ygmg.s3.ap-northeast-2.amazonaws.com/profile/35b67b48-8399-4874-ab59-52793e8f20351677401341966.jpg", "USER");
INSERT INTO member(id, kakao_email, member_birth, member_name, member_nickname, member_weight, profile_url, role) VALUES(2, "susu9941@naver.com", "0503", "혜수", "꾸징", 12, "https://ygmg.s3.ap-northeast-2.amazonaws.com/profile/d359e29b-137b-406f-bf12-e4ee6244e229%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C.jpeg-15.jpg", "USER");
INSERT INTO member(id, kakao_email, member_birth, member_name, member_nickname, member_weight, profile_url, role) VALUES(3, "o227@naver.com", "0806", "dssss", "똥그리", 25, "https://ygmg.s3.ap-northeast-2.amazonaws.com/profile/59701fbe-9c49-4661-8b1f-a804de52d6e4f0b7f1c1710848664c1698b64ee306e0.jpg", "USER");
